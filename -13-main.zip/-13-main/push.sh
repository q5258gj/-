git add .
git commit -m "build"
git push